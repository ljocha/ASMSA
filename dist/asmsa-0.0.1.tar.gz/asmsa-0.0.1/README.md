# ASMSA
Analysis and Sampling of Molecular Simulations by adversarial Autoencoders

[![Binder](https://binderhub.cloud.e-infra.cz/badge_logo.svg)](https://binderhub.cloud.e-infra.cz/v2/git/https%3A%2F%2Fgitlab.ics.muni.cz%2F485413%2FASMSA/refs/heads/kl_divergence)

## Description
TODO

## Badges
TODO

## Getting started
TODO

## Test and Deploy
TODO


## Visuals
TODO (screenshots, ...)

## Installation
TODO

## Usage
TODO

## Support
TODO

## License
TODO

## Project status
In development... No main usable version released yet
